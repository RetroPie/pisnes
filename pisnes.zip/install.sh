#/bin/sh

cd /usr/local/bin/indiecity/InstalledApps/pisnes/Full
chmod 777 ./snes9x ./snes9x.cfg ./roms ./skins 
